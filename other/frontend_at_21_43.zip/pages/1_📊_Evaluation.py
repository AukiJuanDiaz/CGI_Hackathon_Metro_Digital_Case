import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
import plotly.graph_objects as go

# Change the color scheme to a few custom colors of my company
# Use them instead of the default Streamlit colors




st.title("ChatBot Evaluation Dashboard")

st.write("Compare different versions of the Metro Bots!")

# Initialize session state
if "left_data" not in st.session_state:
    st.session_state.left_data = None

if "right_data" not in st.session_state:
    st.session_state.right_data = None

# Two main sections + divider
left, divider, right = st.columns([1, 0.02, 1])

available_bots = ["FriendlyBot v1.0", "FriendlyBot v1.1", "PoliteBot v1.0"]
metrics = ["Example Metric", "Accuracy", "Correctness", "Relevance", "Clarity", "Hallucination Rate"]

# Divider
with divider:
    st.markdown(
        "<div style='border-left: 2px solid #ccc; height: 100vh; margin: auto;'></div>",
        unsafe_allow_html=True
    )


# ---------------------------
# Helper function for charts
# ---------------------------
def render_chart(df, title):
    chart = (
        alt.Chart(df)
        .mark_bar()
        .encode(
            x=alt.X(
                "labels:N",
                sort=None,
                title="Metric",
                axis=alt.Axis(labelAngle=-45)   # rotate x labels
            ),
            y=alt.Y(
                "values:Q",
                scale=alt.Scale(domain=[0, 1]),
                title="Score"
            ),
            tooltip=["labels", "values"]
        )
        .properties(
            width="container",  # flexible width to fit the column
            height=600,         # taller chart
            title=title
        )
    )
    st.altair_chart(chart, use_container_width=True)


# ---------------------------
# LEFT PANEL
# ---------------------------
with left:
    st.subheader("Chatbot 1")

    option_left = st.selectbox(
        "Select a ChatBot to evaluate:",
        available_bots,
        key="left_select"
    )

    if st.button("Run Evaluation", key="run_left"):
        st.session_state.left_data = pd.DataFrame({
            "labels": metrics,
            "values": np.random.rand(len(metrics))
        })

    if st.session_state.left_data is not None:
        render_chart(st.session_state.left_data, "Evaluation Result")


# ---------------------------
# RIGHT PANEL
# ---------------------------
with right:
    st.subheader("Chatbot 2")

    option_right = st.selectbox(
        "Select a ChatBot to evaluate:",
        available_bots,
        key="right_select"
    )

    if st.button("Run Evaluation", key="run_right"):
        st.session_state.right_data = pd.DataFrame({
            "labels": metrics,
            "values": np.random.rand(len(metrics))
        })

    if st.session_state.right_data is not None:
        render_chart(st.session_state.right_data, "Evaluation Result")


# --------------------------- 
# SPIDER CHART
#---------------------------
if st.session_state.left_data is not None and st.session_state.right_data is not None:
    st.subheader("Comparison Spider Chart")

    def make_spider_chart(left_df, right_df, left_label, right_label):
        categories = left_df['labels'].tolist()
        N = len(categories)

        left_values = left_df['values'].tolist()
        right_values = right_df['values'].tolist()

        # Create data for Altair
        spider_data = []
        for i, category in enumerate(categories):
            spider_data.append({
                'metric': category,
                'value': left_values[i],
                'bot': left_label
            })
            spider_data.append({
                'metric': category,
                'value': right_values[i],
                'bot': right_label
            })
        
        df_spider = pd.DataFrame(spider_data)



        fig = go.Figure()

        # Add traces for each bot
        for bot_name in df_spider['bot'].unique():
            bot_data = df_spider[df_spider['bot'] == bot_name]
            fig.add_trace(go.Scatterpolar(
            r=bot_data['value'].tolist(),
            theta=bot_data['metric'].tolist(),
            fill='toself',
            name=bot_name
            ))

        fig.update_layout(
            polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1]
            )
            ),
            showlegend=True,
            height=600
        )

        st.plotly_chart(fig, use_container_width=True)
        


    make_spider_chart(
        st.session_state.left_data,
        st.session_state.right_data,
        option_left,
        option_right
    )



